// import React from 'react'
import { useEffect, useState, React } from 'react'
// import { Link } from 'react-router-dom'
import { getProductsDetails } from '../services/home.service';
import { useParams } from 'react-router-dom';

function Product() {
    const [product, setProduct] = useState([]);
    let {id} = useParams()
    useEffect(() => {
        getProductsDetails(id).then((r) => {
            setProduct(r.data);
        });

    }, []);

    return (
        <div className="row my-0 mx-0 p-0 d-flex justify-content-center">
            {product.length > 0 ? (
                product.map((v, i) => (
                    <div className='text-link col-md-5 d-flex flex-column  align-items-center flex-wrap pt-3 pb-0 m-3'>
                        <img src={`/assets/images/${v.image}`} alt='category' className='product-img' />
                        <p className='text-success p-1 w-100 price mt-2 mb-0'>{v.price}</p>
                        <h5 className='h5 my-2 title px-3 py-2'>{v.name}</h5>
                        <p className='pb-4 pe-4 ps-5 pt-1 w-100 m-0 title'>{v.description}</p>
                    </div>
                ))
            ) : (
                <div className="alert alert-warning">No Product Found!</div>
            )}

        </div>
    )
}

export default Product
